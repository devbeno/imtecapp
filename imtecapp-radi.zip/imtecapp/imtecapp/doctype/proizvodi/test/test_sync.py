import unittest
from imtecapp.imtecapp.doctype.proizvodi.sync import sync_products_to_prestashop

class TestPrestaSync(unittest.TestCase):
    def test_sync_products(self):
        sync_products_to_prestashop()
        self.assertTrue(True)

if __name__ == '__main__':
    unittest.main()