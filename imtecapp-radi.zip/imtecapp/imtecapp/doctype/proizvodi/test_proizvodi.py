# import unittest
# from unittest.mock import patch, MagicMock
# from imtecapp.imtecapp.doctype.proizvodi.proizvodi import sync_product_to_prestashop
from frappe.tests.utils import FrappeTestCase
class TestProizvodi(FrappeTestCase):

    # def setUp(self):
    #     # Setup code to initialize any necessary data or state
    #     pass

    # def tearDown(self):
    #     # Cleanup code to reset any changes made during tests
    #     pass

    # @patch('imtecapp.imtecapp.doctype.proizvodi.proizvodi.requests.get')
    # @patch('imtecapp.imtecapp.doctype.proizvodi.proizvodi.requests.post')
    # @patch('imtecapp.imtecapp.doctype.proizvodi.proizvodi.requests.put')
    # @patch('imtecapp.imtecapp.doctype.proizvodi.proizvodi.frappe.get_doc')
    # @patch('imtecapp.imtecapp.doctype.proizvodi.proizvodi.frappe.db.commit')
    # def test_sync_existing_product(self, mock_commit, mock_get_doc, mock_put, mock_post, mock_get):
    #     # Mocking the product document
    #     mock_product = MagicMock()
    #     mock_product.art_sifra = 'test_sifra'
    #     mock_product.art_naziv = 'Test Product'
    #     mock_product.prestashop_category_id = '1'
    #     mock_product.prestashop_manufacturer_id = '1'
    #     mock_product.vpc = 100
    #     mock_product.aktivan = 1
    #     mock_product.stanje = 10
    #     mock_product.kataloski = '12345'
    #     mock_product.prestashop_id = '1'
    #     mock_product.status = 'for_update'
    #     mock_get_doc.return_value = mock_product

    #     # Mocking the PrestaShop API responses
    #     mock_get.return_value.status_code = 200
    #     mock_get.return_value.text = '<prestashop><product><id>1</id></product></prestashop>'
    #     mock_put.return_value.status_code = 200

    #     # Call the function
    #     result = sync_product_to_prestashop('test_sifra')

    #     # Assertions
    #     self.assertIn('synced successfully', result)
    #     mock_get_doc.assert_called_once_with('Proizvodi', {'art_sifra': 'test_sifra'})
    #     mock_put.assert_called_once()
    #     mock_commit.assert_called()

    # @patch('imtecapp.imtecapp.doctype.proizvodi.proizvodi.requests.get')
    # @patch('imtecapp.imtecapp.doctype.proizvodi.proizvodi.requests.post')
    # @patch('imtecapp.imtecapp.doctype.proizvodi.proizvodi.requests.put')
    # @patch('imtecapp.imtecapp.doctype.proizvodi.proizvodi.frappe.get_doc')
    # @patch('imtecapp.imtecapp.doctype.proizvodi.proizvodi.frappe.db.commit')
    # def test_sync_new_product(self, mock_commit, mock_get_doc, mock_put, mock_post, mock_get):
    #     # Mocking the product document
    #     mock_product = MagicMock()
    #     mock_product.art_sifra = 'new_sifra'
    #     mock_product.art_naziv = 'New Product'
    #     mock_product.prestashop_category_id = '1'
    #     mock_product.prestashop_manufacturer_id = '1'
    #     mock_product.vpc = 100
    #     mock_product.aktivan = 1
    #     mock_product.stanje = 10
    #     mock_product.kataloski = '12345'
    #     mock_product.prestashop_id = None
    #     mock_product.status = 'for_insert'
    #     mock_get_doc.return_value = mock_product

    #     # Mocking the PrestaShop API responses
    #     mock_get.return_value.status_code = 200
    #     mock_get.return_value.text = '<prestashop><product></product></prestashop>'
    #     mock_post.return_value.status_code = 201
    #     mock_post.return_value.text = '<prestashop><product><id>2</id></product></prestashop>'

    #     # Call the function
    #     result = sync_product_to_prestashop('new_sifra')

    #     # Assertions
    #     self.assertIn('created successfully', result)
    #     mock_get_doc.assert_called_once_with('Proizvodi', {'art_sifra': 'new_sifra'})
    #     mock_post.assert_called_once()
    #     mock_commit.assert_called()

    # @patch('imtecapp.imtecapp.doctype.proizvodi.proizvodi.requests.get')
    # @patch('imtecapp.imtecapp.doctype.proizvodi.proizvodi.frappe.get_doc')
    # @patch('imtecapp.imtecapp.doctype.proizvodi.proizvodi.frappe.db.commit')
    # def test_sync_product_exception(self, mock_commit, mock_get_doc, mock_get):
    #     # Mocking the product document
    #     mock_product = MagicMock()
    #     mock_product.art_sifra = 'error_sifra'
    #     mock_get_doc.return_value = mock_product

    #     # Mocking the PrestaShop API responses to raise an exception
    #     mock_get.side_effect = Exception('API Error')

    #     # Call the function
    #     result = sync_product_to_prestashop('error_sifra')

    #     # Assertions
    #     self.assertIn('An unexpected error occurred', result)
    #     mock_get_doc.assert_called_once_with('Proizvodi', {'art_sifra': 'error_sifra'})
    #     mock_commit.assert_not_called()