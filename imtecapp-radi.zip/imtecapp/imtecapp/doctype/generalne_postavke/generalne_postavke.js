// Copyright (c) 2024, Imtec and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Generalne Postavke", {
// 	refresh(frm) {

// 	},
// });
